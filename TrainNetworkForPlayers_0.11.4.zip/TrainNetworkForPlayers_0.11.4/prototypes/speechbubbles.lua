data:extend({
    {
        name = "tnp-speechbubble",
        type = "speech-bubble",
        flags = {
            "not-on-map",
            "placeable-off-grid"
        },
        style = "tnp_speechbubble"
    }
})